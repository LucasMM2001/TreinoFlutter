import "contato.dart";


class ListaDeContatos {
  List<Contato> contatos = [
    Contato(
        nome: "Xaropinho",
        email: "xaropinho@gmail.com",
        imagem: "imagem/O_Xaropinho.jpg"),
    Contato(
        nome: "Louro José",
        email: "loro@gmail.com",
        imagem: "imagem/louro2.jpg"),
    Contato(
        nome: "Baby Familia Dinossauro",
        email: "baby@gmail.com",
        imagem: "imagem/babyDino.jpg"),
  ];

  int contarFavoritos() {
    return contatos.where((contato) => contato.favorito).length;
  }
}
