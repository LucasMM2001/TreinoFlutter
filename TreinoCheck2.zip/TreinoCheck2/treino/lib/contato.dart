class Contato {
  final String nome;
  final String email;
  bool favorito;
  final String imagem;

  Contato({required this.nome, required this.email, this.favorito = false, required this.imagem});

  void alternarFavorito() {
    favorito = !favorito;
  }
}