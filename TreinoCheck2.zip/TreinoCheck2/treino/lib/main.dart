import 'package:flutter/material.dart';
import "contato.dart";
import "listaContato.dart";

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final ListaDeContatos listaDeContatos = ListaDeContatos();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Contatos Favoritos',
      theme: ThemeData(
        primaryColor: Colors.blueAccent,
      ),
      home: ContatosScreen(listaDeContatos: listaDeContatos),
    );
  }
}

class ContatosScreen extends StatefulWidget {
  final ListaDeContatos listaDeContatos;

  ContatosScreen({required this.listaDeContatos});

  @override
  _ContatosScreenState createState() => _ContatosScreenState();
}

class _ContatosScreenState extends State<ContatosScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Text(
                'Contatos Favoritos ${widget.listaDeContatos.contarFavoritos()}'),
          ],
        ),
      ),
      body: ListView.builder(
        itemCount: widget.listaDeContatos.contatos.length,
        itemBuilder: (context, index) {
          final contato = widget.listaDeContatos.contatos[index];
          return ListTile(
            leading: CircleAvatar(
              backgroundImage: NetworkImage(contato.imagem),
            ),
            title: Text(contato.nome),
            subtitle: Text(contato.email),
            trailing: IconButton(
              icon: Icon(Icons.favorite,
                  color: contato.favorito ? Colors.red : null),
              onPressed: () {
                setState(() {
                  contato.alternarFavorito();
                });
              },
            ),
          );
        },
      ),
    );
  }
}
