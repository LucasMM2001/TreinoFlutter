package com.example.treino

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
